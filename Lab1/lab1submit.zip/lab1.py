# Sample Coding Questions 01 Week 01
# Henrique Custodio

arr = [1, 4, 7, 9]

a = 1
b = 2
c = 3
d = 4

e = a - ((b ** c) // d) + (a % c)

temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))

userAge = int(input("Please enter your age: "))
userAge += 22
print("Now showing the shop items filtered by age: {}".format(userAge))
